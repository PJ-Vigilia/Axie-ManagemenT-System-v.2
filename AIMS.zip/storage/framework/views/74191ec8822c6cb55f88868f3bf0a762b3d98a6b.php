
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/user/home.css')); ?>">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10 image-container">
                <div class="row h-100 justify-content-end d-flex py-3 align-items-center content-container">
                    <div class="col-md-5 content rounded px-3 py-2">
                        <div class="fs-5 text-center mb-2">
                            Axie Infinity Management System
                        </div>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                    <th scope="col">Account</th>
                                    <th scope="col">Axies</th>
                                    <th scope="col">SLP</th>
                                    <th scope="col">Transaction</th>
                                    </tr>
                                </thead>
                                <tbody id="tbl_home_tbody">
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/user/home.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\It\Desktop\Portfolio\AIMS\resources\views/user/home.blade.php ENDPATH**/ ?>