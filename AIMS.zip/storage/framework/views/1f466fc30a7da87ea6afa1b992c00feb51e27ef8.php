
<?php $__env->startSection('content'); ?>
    <div class="container bg-white py-3 px-4">
        <div class="row">
            <div class="col-md">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Account name</th>
                            <th scope="col">Type</th>
                            <th scope="col">Date created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td scope="row">1</td>
                            <td>Sakalam</td>
                            <td>Personal</td>
                            <td>Jan 1, 2020</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="col-md bg-danger">b</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\It\Desktop\Portfolio\AIMS\resources\views/user/axieAccount.blade.php ENDPATH**/ ?>